/*
  Authors : initappz (Rahul Jograna)
  Website : https://initappz.com/
  App Name : Washing Wala Full App Ionic 6 Capacitor
  This App Template Source code is licensed as per the
  terms found in the Website https://initappz.com/license
  Copyright and Good Faith Purchasers © 2024-present initappz.
*/
export const environment = {
  production: false,
  baseUrl: 'https://api.domain.com/public/api/',
  imageUrl: 'https://api.domain.com/storage/images/',
};
